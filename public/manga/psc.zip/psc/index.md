---
title: "片山愁特辑·小豆丁哥哥"
date: 2025-05-01
draft: false
password: dmc6
tags: 
  - 图集
imagePrefix: "https://mayday44.xyz/psc/"  
imageCount: 137
imageExt: ".png" 
startIndex: 1
---
作者：片山愁  
翻译：@马拉桑喝酒醉  
嵌字：@马拉桑喝酒醉